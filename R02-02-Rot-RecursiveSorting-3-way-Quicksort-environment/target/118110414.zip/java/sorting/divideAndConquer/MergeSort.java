package sorting.divideAndConquer;

import sorting.AbstractSorting;

/**
 * Merge sort is based on the divide-and-conquer paradigm. The algorithm
 * consists of recursively dividing the unsorted list in the middle, sorting
 * each sublist, and then merging them into one single sorted list. Notice that
 * if the list has length == 1, it is already sorted.
 */
public class MergeSort<T extends Comparable<T>> extends AbstractSorting<T> {

	@Override
	public void sort(T[] array, int l, int r) {
		if (verifica(array, l, r)) {
			if (l < r) {
				int middle = l + (r - l) / 2;
				sort(array, l, middle);
				sort(array, middle + 1, r);
				merge(array, l, middle, r);
			}
		}
		
	}
	
	private void merge(T[] array, int l, int m, int r){
		int size = array.length;
		T[] aux = (T[]) new Comparable[size];
		
		for (int i = l; i <= r; i++) {
			aux[i] = array[i];
		}
		
		int i = l;
		int k = l;
		int mid = m + 1;
		
		while (i <= m && mid <= r) {
			if (aux[i].compareTo(aux[mid]) < 0) {
				array[k] = aux[i];
				i++;
			}
			
			else {
				array[k] = aux[mid];
				mid++;
			}
			
			k++;
		}
		
		while (i <= m) {
			array[k] = aux[i];
			k++;
			i++;
		}
		
		while (mid <= m) {
			array[k] = aux[mid];
			k++;
			mid++;
		}
	}
	
	private boolean verifica(T[] array, int l, int r) {
		boolean result = true;
		
		if (array == null || array.length <= 0) {
			result = false;
		} else if (l >= r || l < 0) {
			result = false;
		} else if (r > array.length || l >= array.length
				|| r <= 0) {
			result = false;
		}
		
		return result;
	}
	

}